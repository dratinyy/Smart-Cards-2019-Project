#include "windef.h"
#include "askcsc.h"
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>

#define	DO_SAM_PPS
#define DISPLAY_TRANSACTION_INFO

void WaitKey (BOOL bExit)
{
	if (bExit)
		printf("Press <Enter> to exit");
	else
		printf("Press <Enter> to continue");

	getchar();
	if (!bExit)
		printf("\r                       \r");
}

void BinToHEX (BYTE *Buffer, DWORD dwLen)
{
	for (DWORD dwIndex=0;dwIndex  < dwLen;dwIndex++)
		printf ("%2.2X ",Buffer[dwIndex]);
}

DWORD WINAPI CouplerCommand(DWORD Timeout,BYTE* BufIN,
							 DWORD LnIN,BYTE* BufOUT,LPDWORD LnOUT)
{
	BYTE bSendBuffer[256];
	DWORD dwLen;

	bSendBuffer[0] = 0x80;
	bSendBuffer[1] = (BYTE) LnIN;
	memcpy (bSendBuffer+2,BufIN,LnIN);
	dwLen = 2+LnIN+1;
	bSendBuffer[dwLen-1] = 0x00;
	CSC_AddCRC (bSendBuffer,&dwLen);
	return CSC_SendReceive (Timeout,bSendBuffer,dwLen,BufOUT,LnOUT);
}

int main(int argc, char *argv[])
{
	BYTE bRecvBuffer[256];
	DWORD dwRecvLength;
	DWORD dwReturn;
	DWORD dwLen;
	char sComPort[128];
	WORD wStatus;
	WORD wRFSpeed;
	DWORD dwHostSpeed;

	BYTE VersionSAM[]={0x80,0x60,0x00,0x00,0x00};

	if (argc == 4)
		dwHostSpeed = atoi (argv[3]);
	else
		dwHostSpeed = 115200;

	if (argc >=3)
		wRFSpeed=atoi (argv[2]);
	else
		wRFSpeed=106;

	if (argc >= 2)
	{
		strcpy (sComPort,"/dev/");
		strcat (sComPort,argv[1]);
	}
	else
		strcpy (sComPort,"/dev/ttyS1");

	printf("DESFire example code, using the coupler commands.\r\n");
	printf("Usage: \"desfirefuncs <optional serial port, default is ttyS1> <optional RF speed> <optional Host speed>\"\r\n\n");
	CSC_ChangeDLLSpeed (dwHostSpeed);
	printf ("Open %s at %d bps...",sComPort,dwHostSpeed);

	if ((dwReturn = CSC_Open (sComPort)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\n");

	printf("NXP AV2 SAM must be put in the slot 1.\r\n");
	WaitKey (0);

	// Version
	printf ("Coupler version...");
	if ((dwReturn = CSC_VersionCSC (bRecvBuffer)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("%s\r\n",bRecvBuffer);
	// End Version

	// EHP Param No select appli
	printf ("EHP Param to avoid auto selection of Calypso application...");
	if ((dwReturn = CSC_EHP_PARAMS_EXT (0x01,0x01,0x00,0x00,0x00,0x00,0x00,0,NULL,0,0)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\n");
	// End EHP Param

	// Set RF communication speed
	printf ("Set communication speed to %d kb/s...",wRFSpeed);
	BYTE SET_RF_SPEED[]={0x10,0x01,0x04,0x10,0xCC,0xCC,0x00};

	switch (wRFSpeed)
	{
	case 212:
		SET_RF_SPEED[4]=SET_RF_SPEED[5]=0x01;
		break;
	case 424:
		SET_RF_SPEED[4]=SET_RF_SPEED[5]=0x02;
		break;
	case 848:
		SET_RF_SPEED[4]=SET_RF_SPEED[5]=0x03;
		break;
	default: // 106
		SET_RF_SPEED[4]=SET_RF_SPEED[5]=0x00;
		break;
	}
	dwLen = sizeof (SET_RF_SPEED);
	if ((dwReturn = CouplerCommand (200,SET_RF_SPEED,dwLen,bRecvBuffer,&dwRecvLength)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\n");
	// End Set RF communication speed


	// Reset SAM ISO7816
	printf ("Reset SAM ISO7816...");
	if ((dwReturn = CSC_ResetSAMExt (1,0,1,&dwRecvLength,bRecvBuffer)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\nSAM ATR: ");
	BinToHEX (bRecvBuffer,dwRecvLength);
	printf ("\r\n");
	// End Reset SAM ISO7816

#ifdef DO_SAM_PPS
	// SAM Set PPS  0x86 or from ATR (0x18)
	printf ("SAM Set PPS...");

	if (((dwReturn = CSC_SetSAMBaudratePPS (1,bRecvBuffer[2],&wStatus)) != RCSC_Ok) // get FI/DI value from SAM ATR (150 Kbps)
//	if (((dwReturn = CSC_SetSAMBaudratePPS (1,0x86,&wStatus)) != RCSC_Ok) // Max SAM speed (1,2 Mbps)
			|| (wStatus != 0))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\n");
	// End SAM Set PPS
#endif

	// SAM_GetVersion
	BYTE VERSION_SAM[]={0x80,0x60,0x00,0x00,0x00};
	printf ("SAM_GetVersion...");
	if ((dwReturn = CSC_ISOCommandSAMExt (1,sizeof(VERSION_SAM),VERSION_SAM,1,&dwRecvLength,bRecvBuffer)) != RCSC_Ok)
	{
		printf ("Error 0x%X\r\n",dwReturn);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\nSAM VERSION: ");
	BinToHEX (bRecvBuffer,dwRecvLength-1);
	printf ("\r\n");
	// End SAM_GetVersion


///////   CARD DETECTION
	printf("\r\nPut a DESFire card on the reader.\r\n");
	WaitKey (0);

	printf ("\n***** DETECTION *****\r\n\n");

	// Enter Hunt Phase Type A
	printf ("Enter Hunt Phase Type A...");
	sCARD_SearchExt SearchExt;
	DWORD search_mask;
	BYTE COM;
	BYTE atr[64];
	DWORD atrLength;
	search_mask = SEARCH_MASK_ISOA;
	memset (&SearchExt,0,sizeof(SearchExt));
	SearchExt.ISOA=1;

	if ((dwReturn = CSC_SearchCardExt(&SearchExt,search_mask,0x01,0x44,&COM,&atrLength,atr)) != RCSC_Ok
			|| (COM != 0x02))
	{
		printf ("Error 0x%X Card detected: %2.2X \r\n",dwReturn,COM);
		WaitKey (1);
		return 1;
	}
	printf ("OK\r\nCard UID: ");
	BinToHEX (bRecvBuffer+2,7);
	printf ("\r\n");
	// End Enter Hunt Phase Type A

	printf ("\n***** CARD INITIALIZATION *****\r\n\n");

	// Authenticate Key 00
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Authenticate Key 00...");
#endif									  // PICC Mode	KN    KV   Type, LgDiv
	if ((dwReturn = DESFIRE_AuthenticateEV1 (0x00,0x00,0x01, 0x00, 0x00, 0,    NULL, &wStatus)) != RCSC_Ok
		|| (wStatus != 0x9000))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Authenticate

	// Change master Key PICC
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("ChangeKey 00...");
#endif								  //CKN   CKV   NKN	  NKV  KCOMP Cfg, Algo, LgDiv
	if ((dwReturn = DESFIRE_ChangeKey (0x01, 0x00, 0x01, 0x00, 0x01, 0,   0x00, 0x00, NULL, &wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Authenticate

	// Authenticate Key 00
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Authenticate Key 00...");
#endif									  // PICC Mode	KN    KV   Type, LgDiv
	if ((dwReturn = DESFIRE_AuthenticateEV1 (0x00,0x00,0x01, 0x00, 0x00, 0,    NULL, &wStatus)) != RCSC_Ok
		|| (wStatus != 0x9000))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Authenticate

	// Format PICC
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Format PICC...");
#endif					
	if ((dwReturn = DESFIRE_FormatPICC (&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Format PICC

	// Create Application 11 22 33
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Create Application 11 22 33...");
#endif
	if ((dwReturn = DESFIRE_CreateApplication ((LPBYTE)"\x11\x22\x33",0x0F,0x02, &wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Create Application

	// Select Application 11 22 33
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Select Application 11 22 33...");
#endif
	if ((dwReturn = DESFIRE_SelectApplication ((LPBYTE)"\x11\x22\x33",&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Select Application

	// Create Data File 00
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Create Data File 00...");
#endif
	if ((dwReturn = DESFIRE_CreateStandardDataFile (0x00,0x01,0x0110,(LPBYTE)"\x00\x00\x20",&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Create Data File

	// Create Backup File 01
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Create Backup File 01...");
#endif
	if ((dwReturn = DESFIRE_CreateBackUpDataFile (0x01,0x00,0x0110,(LPBYTE)"\x00\x00\x30",&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Create Backup Data File

	// Create Cyclic Record File 04
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Create Cyclic Record File 04...");
#endif
	if ((dwReturn = DESFIRE_CreateCyclicRecordFile (0x04,0x00,0x0110,(LPBYTE)"\x00\x00\x20",(LPBYTE)"\x00\x00\x05",&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Create Cyclic Record File





///////   TRANSACTION
	printf ("\n***** TRANSACTION *****\r\n\n");

	// start time measure
	  struct timeval tv1,tv2;
	  struct timezone tz;
	  long long diff;
	  int i;
	  gettimeofday(&tv1, &tz);

	// Select Application 11 22 33
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Select Application 11 22 33...");
#endif
	if ((dwReturn = DESFIRE_SelectApplication ((LPBYTE)"\x11\x22\x33",&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Select Application


	// Prepare Authentication KeyN 01 KeyV 00
	// a alternate way to perform autnetication, used in pair with DESFIRE_Authenticate
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Prepare Authentication KeyN 01 KeyV 00...");
#endif
	if ((dwReturn = DESFIRE_PrepareAuthentication (0,1,0,&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif

	// End Prepare Authentication


	// Authenticate Key 01
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Authenticate Key 01...");
#endif
	if ((dwReturn = DESFIRE_Authenticate (0x01,&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9000))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Authenticate

	// Read File 00
	BYTE DESFIRE_READ_DATA[]={0x11,0x1E,0x00,0x00,0x00,0x00,0x00,0x20};
	dwLen = sizeof (DESFIRE_READ_DATA);
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Read File 00...");
#endif
	WORD NumByteRead;
	BYTE DataRead[256];

	if ((dwReturn = DESFIRE_ReadData (0x00,0x01,0x0000,0x0020,&wStatus,&NumByteRead,DataRead)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Read File

	// Read File 01
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Read File 01...");
#endif
	if ((dwReturn = DESFIRE_ReadData (0x01,0x00,0x0000,0x0030,&wStatus,&NumByteRead,DataRead)) != RCSC_Ok
			|| (wStatus != 0x9100))
		{
			printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
			WaitKey (1);
			return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Read File


	// Write Record File 04
	BYTE DATA_RECORD[]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x10};
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Write Record File 04...");
#endif
	if ((dwReturn = DESFIRE_WriteRecord (0x04,0x00,0x0000,0x0010,DATA_RECORD,&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4 \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Write Record File


	// Commit Transaction
	BYTE DESFIRE_COMMIT[]={0x11,0x09};
	dwLen = sizeof (DESFIRE_COMMIT);
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Commit Transaction...");
#endif
	if ((dwReturn = DESFIRE_CommitTransaction (&wStatus)) != RCSC_Ok
		|| (wStatus != 0x9100))
	{
		printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
		WaitKey (1);
		return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Commit Transaction

	// Read Record 04
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("Read Record 04...");
#endif
	if ((dwReturn = DESFIRE_ReadRecord (0x04,0x00,0x0000,0x0001,0x0020,&wStatus,&NumByteRead,DataRead)) != RCSC_Ok
			|| (wStatus != 0x9100))
		{
			printf ("Error 0x%X Status: %4.4X \r\n",dwReturn,wStatus);
			//WaitKey (1);
			//return 1;
	}
#ifdef DISPLAY_TRANSACTION_INFO
	printf ("OK\r\n");
#endif
	// End Read File

	gettimeofday(&tv2, &tz);
	diff=(tv2.tv_sec-tv1.tv_sec) * 1000000L + (tv2.tv_usec-tv1.tv_usec);

	printf ("Transaction time:   %ld ms  \r\n",diff/1000L);


	CSC_Close ();
	WaitKey (1);
	return 0;
}

