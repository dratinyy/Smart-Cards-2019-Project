/*****************************************************************
 Interface Windows Functions for CSC Module ( WINCSC.C )

  Linux plateform

  Copyright (C)1999-2014 by ASK SOPHIA ANTIPOLIS FRANCE
  All right reserved.

 *****************************************************************/



/* Includes for constants, external variables and structures ****/
#include "windef.h"
#include <string.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/select.h>
#include <termios.h>
#include <stdio.h>
#include <unistd.h>

#include "csc_def.h"
#include "csc_ord.h"

#define __WIN_CSC__
#include "wincsc.h"    // Interface WIN Fonctions prototypes


/* Internal constants *******************************************/
#define INVALID_HANDLE_VALUE -1
#define OPEN_FLAGS (O_RDWR | O_NONBLOCK)
static int m_fd = 0; // Serial Communication handle

/****************************************************************/
BOOL WINAPI wCSC_OpenCOM(LPSTR ComName)
/*****************************************************************
Open the PC communication port

INPUTS
  ComName           Communication port Name (ex: "COM1" or "LPT1") 

RETURNS
  TRUE              Function success
	FALSE             Function fail
 *****************************************************************/
{
	int             fd;
	int             i;
	struct termios  tty;

	/* Open communication line
	 */
	if ((fd = open (ComName, OPEN_FLAGS)) < 0) {
		return FALSE;
	}

	/* Input mode : raw mode
	 */
	tty.c_iflag = 0;

	/* Output mode : raw mode
	 */
	tty.c_oflag = 0;

	/* Local mode : raw
	 */
	tty.c_lflag = 0;

	/* Control mode
	 * Set baud rate, 8bits per byte, no parity, 1 stop bit, ready to receive, local mode
	 */
	tty.c_cflag = CS8 | CREAD | CLOCAL;

	switch (ComSpeed)
	{
	case 230400:
		cfsetospeed( &tty, B230400);
		cfsetispeed( &tty, B230400);
		break;
	case 460800:
		cfsetospeed( &tty, B460800);
		cfsetispeed( &tty, B460800);
		break;
	default:
		cfsetospeed( &tty, B115200);
		cfsetispeed( &tty, B115200);
		break;
	}
	/* Special characters
	 */
	for (i = 0; i < NCCS; tty.c_cc[i++] = 0);

	/* Set configuration
	 */
	if (tcsetattr( fd, TCSANOW, &tty) == INVALID_HANDLE_VALUE) {
		return -1;
	}

	/* Non blocking line
	 */
	fcntl( fd, F_SETFL, O_NONBLOCK | fcntl( fd, F_GETFL));

	m_fd = fd;

	return TRUE;
}

/****************************************************************/
BOOL WINAPI wCSC_CloseCOM(void)
/*****************************************************************
Close the PC communication port

RETURNS
  Always FALSE
 *****************************************************************/
{
	if((m_fd == INVALID_HANDLE_VALUE) || (m_fd==0))
	{
		m_fd=0;
		return FALSE; // COM already Close -> out
	}
	close( m_fd ); // close the COM port
	m_fd=0;

	return FALSE;
}

/****************************************************************/
void WINAPI wCSC_FlushCOM(void)
/*****************************************************************
This Function discard all characters from the output or input
buffer in serial mode.
In parallel mode, discard ONE character from the output buffer of
the parallel interface of the coupler(made to receive reset byte 
0x10).
 *****************************************************************/
{
#ifndef LINUX
	DWORD vDt;
	DWORD TimeOut=1;
	char buf;

	if (bLPT == 1)
	{
		vDt=wCSC_GetTimer(0); // begin timer
		InitPCom(REVERSE);
		while (((_inp(STATUS) & 0x08) != 0x00) && (wCSC_GetTimer(vDt)<=TimeOut));
		buf = _inp(DATA);
		myout(CONTROL,0x27);
		while (((_inp(STATUS) & 0x08) != 0x08) && (wCSC_GetTimer(vDt)<=TimeOut));
		myout(CONTROL,0x25);
	}
	else
	{
		// If the COM close or on error -> out
		if((hCOM == INVALID_HANDLE_VALUE) || (hCOM==NULL))return;

		PurgeComm(hCOM,PURGE_TXABORT | PURGE_TXCLEAR
				| PURGE_RXABORT | PURGE_RXCLEAR );
	}
#else /* LINUX */

	char buf[2];
	// If the COM close or on error -> out
	if((m_fd == INVALID_HANDLE_VALUE) || (m_fd==0))
		return;
	while (read(m_fd, buf, 1) == 1);
#endif /* LINUX */
}

/****************************************************************/
BOOL WINAPI wCSC_SendCOM(BYTE* BufIN,DWORD LnIN)
/*****************************************************************
Send data to the communication port

INPUTS
	BufIN							Frame to send to COM port
	LnIN							BufIN data length

RETURNS
  TRUE              Function success 
	FALSE             Function fails
 *****************************************************************/
{

	/* Serial communication */
	// If the COM close or on error -> Error
	if((m_fd == INVALID_HANDLE_VALUE) || (m_fd==0))
		return FALSE;

	// Send to Comm. port
	if(write(m_fd,(LPSTR)BufIN, LnIN)!=LnIN)
		return FALSE;

	return TRUE; // function success
}

/****************************************************************/
DWORD WINAPI wCSC_iRecCOM(DWORD Len,BYTE* BufOUT)
/*****************************************************************
WARNING : Dimension of 'BufOUT' must be upper than the 
					value of 'Len'
 ******************************************************************
Receive data from the communication port ( Internal function )

INTERNAL FUNCTION

INPUTS
	Len								Number of byte wanted to receive

OUTPUTS
	BufOUT						Received bytes from the COM port

RETURNS
	Number of byte effectively receive
	0 -> Error
 *****************************************************************/
{

	DWORD LenRead;

	// If the COM close or on error -> Error
	if((m_fd == INVALID_HANDLE_VALUE) || (m_fd==0))
		return 0;
	LenRead=read(m_fd, BufOUT, Len);

	if(LenRead == -1)
		return 0;

	return LenRead;
}

/****************************************************************/
INT WINAPI wCSC_ReceiveCOM(DWORD TimeOut,DWORD Len,BYTE* BufOUT)
/*****************************************************************
WARNING : Dimension of 'BufOUT' must be upper than the 
					value of 'Len'
 ******************************************************************
Receive data from the communication port during 'TimeOut' ms

INPUTS
	TimeOut						Time out in milliseconds
	Len								Number of byte wanted to receive

OUTPUTS
	BufOUT						Received bytes from the COM port

RETURNS
  LnOUT							Number of byte effectively receive
										if zero -> error
										if -1 -> timeout
 *****************************************************************/
{
	DWORD vDt;                              // timer lap
	DWORD vLn;                              // Number of byte temporarily receive
	DWORD nb;                                       // Number of byte effectively receive
	BYTE buf[300];          // Local Temp buffer
	int             result;
	fd_set          fds;
	struct timeval  timer;
	DWORD vTo;
	INT nbData;
	WORD wNb;
	*BufOUT=0;

	FD_ZERO( &fds);
	FD_SET( m_fd, &fds);

	nbData=5;

	vDt=wCSC_GetTimer(0); // begin timer

	// Serial communication
	if (TimeOut == 0) {
		result = select( m_fd + 1, &fds, NULL, NULL, NULL);
	} else {
		timer.tv_sec  = TimeOut / 1000;
		timer.tv_usec = (TimeOut % 1000) * 1000;;
		result = select( m_fd + 1, &fds, NULL, NULL, &timer);
	}


	int i = 0;
	BufOUT[0] = 0x01;
	BufOUT[1] = 0x00;

	do
	{
		if (i==2)	// frame timeout
		{
			vDt=wCSC_GetTimer(0); // begin timer
			TimeOut = 100;		  // 100 ms
		}
		while (((wCSC_iRecCOM (1,&BufOUT[i])) != 1) && (wCSC_GetTimer(vDt)<=TimeOut))
			wCSC_IdleLoop ();
		vTo=wCSC_GetTimer(vDt);
		i++;
		if (BufOUT[0] == 0x41)	// DF : Trame etendue 0x41 -> lg = LgLow + 256*LgHigh
		{
			nbData = 6;
			wNb = BufOUT[1] + (256*BufOUT[2]);
		}
		else if (BufOUT[1]==255)
			wNb = BufOUT[1]+BufOUT[2]+1;
		else
			wNb = BufOUT[1];
	}
	while (((i < wNb+nbData) && ((BufOUT[0] == 0x01) || (BufOUT[0] == 0x41))) && (vTo<=TimeOut));		// DF : Trame etendue 0x41

	if (BufOUT[1] == 0x00)
		nb = 1;
	else
		nb = wNb + nbData;
	if(vTo>TimeOut)
		return -1;
	else
		return nb;

}

/****************************************************************/
DWORD WINAPI wCSC_GetTimer(DWORD StartValue)
/*****************************************************************
Start and read a timer in milliseconds

INPUTS
	StartValue				Start value of the counter

RETURNS
  The subtraction between StartValue and the present TickCount
	value
 *****************************************************************/
{
	// x= the number of milliseconds that have elapsed since the system was started.
	DWORD x;
	x=(DWORD)(clock()*1000/CLOCKS_PER_SEC); //time(0);
	return (x-StartValue);
}

/****************************************************************/
void WINAPI wCSC_Delay(DWORD TimeValue)
/*****************************************************************
Wait 'TimeValue' in milliseconds

INPUTS
	TimeValue   				Time to wait in milliseconds
 *****************************************************************/
{
	struct timespec req, rem;

	req.tv_sec=TimeValue/1000;
	req.tv_nsec=(TimeValue-req.tv_sec*1000)*1000;
	nanosleep(&req, &rem);
}

/****************************************************************/
void WINAPI wCSC_IdleLoop(void)
/*****************************************************************
Process the Windows kernel message

 *****************************************************************/
{
	struct timespec req, rem;

	req.tv_sec=0;
	req.tv_nsec=100;
	nanosleep(&req, &rem);
}

/****************************************************************/
DWORD WINAPI wCSC_DebugLog(LPSTR Text,DWORD RetValue)
/*****************************************************************
Write 'text' in a log file

INPUTS
	Text								Text string
	RetValue						Return Value

RETURNS
	Always RetValue
 *****************************************************************/
{
	printf(Text);
	return RetValue;
}
