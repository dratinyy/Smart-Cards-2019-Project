/*****************************************************************
 Interface Windows Functions for CSC Module ( WINCSC.H )

  Linux plateform

  Copyright (C)1999-2014 by ASK SOPHIA ANTIPOLIS FRANCE
  All right reserved.

 *****************************************************************/

#ifndef __WIN_CSC_H__
#define __WIN_CSC_H__


#ifdef __cplusplus
extern "C" {
#endif


/****************************************************************/
BOOL WINAPI wCSC_OpenCOM(LPSTR ComName);
/*****************************************************************
Open the PC communication port

INPUTS
  ComName           Communication port Name  ( ex: "COM1" ) 

RETURNS
  TRUE              Function success
	FALSE             Function fail
 *****************************************************************/


/****************************************************************/
BOOL WINAPI wCSC_CloseCOM(void);
/*****************************************************************
Close the PC communication port

RETURNS
  Always FALSE
 *****************************************************************/



/****************************************************************/
void WINAPI wCSC_FlushCOM(void);
/*****************************************************************
This Function discard all characters from the output or input 
buffer.
 *****************************************************************/


/****************************************************************/
BOOL WINAPI wCSC_SendCOM(BYTE* BufIN,DWORD LnIN);
/*****************************************************************
Send data to the communication port

INPUTS
	BufIN							Frame to send to COM port
	LnIN							BufIN data length

RETURNS
  TRUE              Function success 
	FALSE             Function fails
 *****************************************************************/


/****************************************************************/
INT WINAPI wCSC_ReceiveCOM(DWORD TimeOut,DWORD Len,BYTE* BufOUT);
/*****************************************************************
WARNING : Dimension of 'BufOUT' must be upper than the 
					value of 'Len'
 ******************************************************************
Receive data from the communication port during 'TimeOut' ms

INPUTS
	TimeOut						Time out in milliseconds
	Len								Number of byte wanted to receive

OUTPUTS
	BufOUT						Received bytes from the COM port

RETURNS
  LnOUT							Number of byte effectively receive
										if zero -> error
										if -1 -> timeout
 *****************************************************************/


/****************************************************************/
DWORD WINAPI wCSC_GetTimer(DWORD StartValue);
/*****************************************************************
Start and read a timer in milliseconds

INPUTS
	StartValue				Start value of the counter

RETURNS
  The subtraction between StartValue and the present TickCount
	value
 *****************************************************************/




/****************************************************************/
void WINAPI wCSC_Delay(DWORD TimeValue);
/*****************************************************************
Wait 'TimeValue' in milliseconds

INPUTS
	TimeValue   				Time to wait in milliseconds
 *****************************************************************/



/****************************************************************/
void WINAPI wCSC_IdleLoop(void);
/*****************************************************************
Process the Windows kernel message

 *****************************************************************/


/****************************************************************/
DWORD WINAPI wCSC_DebugLog(LPSTR Text,DWORD RetValue);
/*****************************************************************
Write 'text' in a log file

INPUTS
	Text								Text string
	RetValue						Return Value

RETURNS
	Always RetValue
 *****************************************************************/


#ifdef __cplusplus
}
#endif

#endif /* __WIN_CSC_H__ */
